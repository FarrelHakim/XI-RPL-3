<?php
echo password_hash("farrel123", PASSWORD_DEFAULT);
?>